#include "Graphics.h"
char texbox[20] = { "textb" };
bool E[20];
btVector3 inertia(0, 0, 0);
btTransform ans[40];
btTransform trans;


bool Graphics::Initialize(HWND hwnd, int width, int height)
{
	this->windowWidth = width;
	this->windowHeight = height;
	this->fpsTimer.Start();
	sw[0] = 90;
	sw[1] = 0;
	sw[2] = 0;
	sw[3] = 0;
	//sw[0] = 90;
	if (!InitializeDirectX(hwnd))
		return false;

	if (!InitializeShaders())
		return false;

	if (!InitializeScene())
		return false;

	//Setup ImGui
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	ImGui_ImplWin32_Init(hwnd);
	ImGui_ImplDX11_Init(this->device.Get(), this->deviceContext.Get());
	//ImGui::StyleColorsLight();
	ImGui::StyleColorsClassic();
	return true;
}

void Graphics::RenderFrame()
{
	float bgcolor[] = { 0.7f, 0.3f, 0.3f, 1.0f };
	this->deviceContext->ClearRenderTargetView(this->renderTargetView.Get(), bgcolor);
	this->deviceContext->ClearDepthStencilView(this->depthStencilView.Get(), D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);
	this->deviceContext->IASetInputLayout(this->vertexshader.GetInputLayout());
	this->deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY::D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);//D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST
	this->deviceContext->RSSetState(this->rasterizerState.Get());
	this->deviceContext->OMSetDepthStencilState(this->depthStencilState.Get(), 0);
	this->deviceContext->OMSetBlendState(this->blendState.Get(), NULL, 0xFFFFFFFF);//this->blendState.Get()
	this->deviceContext->PSSetSamplers(0, 1, this->samplerState.GetAddressOf());
	this->deviceContext->VSSetShader(vertexshader.GetShader(), NULL, 0);
	this->deviceContext->PSSetShader(pixelshader.GetShader(), NULL, 0);
	static float alpha = 0.5f;
	{
		this->model.Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha,sw[0]);
		//this->model.DRAWCOLL(camera.GetViewMatrix() * camera.GetProjectionMatrix());
		switch (switch_on)
		{
		case 1:
			rizemove(E[0],0, TRB,lp);
			this->a[0]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha,sw[1]);
			break;
		case 2:
			rizemove(E[0],0, TRB,lp);
			this->a[0]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha,sw[1]);
			rizemove(E[1], 1, TRB,lp);
			this->a[1]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha,sw[2]);
			break;
		case 3:
			rizemove(E[0], 0, TRB, lp);
			this->a[0]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha, sw[1]);
			rizemove(E[1], 1, TRB, lp);
			this->a[1]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha, sw[2]);
			rizemove(E[2], 2, TRB, lp);
			this->a[2]->Draw(camera.GetViewMatrix() * camera.GetProjectionMatrix(), alpha, sw[3]);
		default:
			break;
		}
	}
	static int fpsCounter = 0;
	
	static std::string fpsString = "FPS: 0";
	fpsCounter += 1;
	if (fpsTimer.GetMilisecondsElapsed() > 1000.0)//1000.0
	{
		//model.kk += 1;
		fpsString = "FPS: " + std::to_string(fpsCounter);
		fpsCounter = 0;
		fpsTimer.Restart();
	}
	spriteBatch->Begin();
	spriteFont->DrawString(spriteBatch.get(), StringConverter::StringToWide(fpsString).c_str(), DirectX::XMFLOAT2(0, 0), DirectX::Colors::Gold, 0.0f, DirectX::XMFLOAT2(0.0f, 0.0f), DirectX::XMFLOAT2(1.0f, 1.0f));
	spriteBatch->End();
	static int counter = 0;
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
	//Create ImGui Test Window
	//stk = "bull: " + std::to_string(t.y);
	ImGui::Begin("Test");
	//stk = "time: " + std::to_string(timkk.GetMilisecondsElapsed() /100000);
	std::string co = "model: " + cou;
	if (ImGui::Button("ddd"))
	{
		if (TRV)
		{
			model.IncTTg("Data\\Objects\\Samples\\dodge_challenger.fbx");
		}
		else
		{
			a[ui]->IncTTg("Data\\Objects\\2.fbx");//nanosuit\\nanosuit.obj,Data\\Objects\\2.fbx
			//a[q]->IncTTg(op);
		}
	}
	if (ImGui::Button("bbb"))
	{
		this->rizemodel();
	}
	ImGui::DragInt("trw", &ui, 1, 0, 3);
	ImGui::DragInt("lp che", &lp, 1, 0, TTGGMF);
	ImGui::DragInt("sw che", &sw[lp], 1, 0, TTGGMF);
	if (ImGui::Button("crtacoll"))
	{
		switch (gh)
		{
		case 0:
			cratshamp(shmk, a[ui]->pos2[lp]->x, a[ui]->pos2[lp]->y, a[ui]->pos2[lp]->z, massfk);
			break;
		case 1:
			cratshamp3(shmk, a[ui]->pos2[lp]->x, a[ui]->pos2[lp]->y, a[ui]->pos2[lp]->z, massfk, 4);
			break;
		case 2:
			cratshamp4(2, a[ui]->pos2[lp]->x, a[ui]->pos2[lp]->y, a[ui]->pos2[lp]->z, massfk, 4, 2);
			break;
		case 3:
			cratshamp5(shmk, a[ui]->pos2[lp]->x, a[ui]->pos2[lp]->y, a[ui]->pos2[lp]->z, massfk, 4);
			break;
		default:
			cratshamp2(shmk, a[ui]->pos2[lp]->x, a[ui]->pos2[lp]->y, a[ui]->pos2[lp]->z, massfk, 4);
			break;
		}
	}
	ImGui::DragFloat("cr", &shmk, 0.1f, 0, 20.f);
	ImGui::DragFloat("masss", &massfk, 0.1f, 0, 1.0f);
	ImGui::DragInt("Gray", &gra, 1, 0, -200.0);
	if (ImGui::Button("bcle"))
	{
		if (TRV)
		{
			model.rigmk();
		}
		else
		{
			a[ui]->rigmk();
		}
	}
	if (ImGui::Button("bcle collis"))
	{
		dynam->removeCollisionObject(ball[lp]);
		delete ball[lp];
	}
	if (ImGui::BeginCombo("TRCmode", coug.c_str()))
	{
		if (ImGui::Selectable("ETRQ"))
		{
			if (E[gh])
			{
				E[gh] = true;
			}
			else
			{
				E[gh] = false;
			}
		}
		if (ImGui::Selectable("TRV"))
		{
			if (TRV)
			{
				TRV = false;
			}
			else
			{
				TRV = true;
			}
		}
		if (ImGui::Selectable("eet"))
		{
			if (TRB)
			{
				TRB = false;
			}
			else
			{
				TRB = true;
			}
		}
		if (ImGui::Selectable("kkmq"))
		{
			if (a[ui]->t)
			{
				a[ui]->t =false;
			}
			else
			{
				a[ui]->t =true;
			}
		}
		if (ImGui::Selectable("Drawk"))
		{
			if (a[ui]->g)
			{
				a[ui]->g = false;
			}
			else
			{
				a[ui]->g = true;
			}
		}
		if (ImGui::Selectable("Draw2"))
		{
			if (a[ui]->l)
			{
				a[ui]->l = false;
			}
			else
			{
				a[ui]->l = true;
			}
		}
		ImGui::EndCombo();
	}
	ImGui::Text(std::to_string(TTGGGG -1).c_str());
	ImGui::Text(std::to_string(ui).c_str());
	//ImGui::Text(stk.c_str());
	//std::string clickCount = "Click Count: " + std::to_string(counter);
	//ImGui::Text(clickCount.c_str());
	//ImGui::DragFloat3("Translation X/Y/Z", translationOffset, 0.1f, -12.0f, 12.0f);
	ImGui::DragFloat("Translation X", &tt[ui]->x, 0.1f, -100.0f, 100.0f);
	ImGui::DragFloat("Translation Y", &tt[ui]->y, 0.1f, -100.0f, 100.0f);
	ImGui::DragFloat("Translation Z", &tt[ui]->z, 0.1f, -100.0f, 100.0f);
	if (TTGGGG >0)
	{
		ImGui::DragFloat("roex", &a[ui]->ros2[lp]->x, 0.01f, -10.0f, 10.0f);
		ImGui::DragFloat("roey", &a[ui]->ros2[lp]->y, 0.01f, -10.0f, 10.0f);
		ImGui::DragFloat("roeZ", &a[ui]->ros2[lp]->z, 0.01f, -10.0f, 10.0f);
		ImGui::DragFloat("posx", &a[ui]->pos2[lp]->x, 0.1f, -100.0f, 100.0f);
		ImGui::DragFloat("posy", &a[ui]->pos2[lp]->y, 0.1f, -100.0f, 100.0f);
		ImGui::DragFloat("posz", &a[ui]->pos2[lp]->z, 0.1f, -100.0f, 100.0f);
		ImGui::DragInt("meshs", &a[ui]->mp, 1, 0, 25);
	}
	ImGui::DragFloat("Alpha", &alpha, 0.1f, 0.0f, 1.0f);
	ImGui::DragInt("switc_on", &switch_on, 1, 0, TTGMMMM);
	ImGui::DragInt("boolk", &gh, 1, 0, TTGMMMM);
	ImGui::End();
	ImGui::Begin("kf");
	ImGui::InputText("Testgdo", texbox, IM_ARRAYSIZE(texbox));
	if (ImGui::ListBoxHeader(co.c_str()))
	{
		if (ImGui::Selectable("BACK"))
		{
			this->m = 0;
			this->rize();
			cou = "BACK";
			//timkk.Stop();
		}
		if (ImGui::Selectable("FRONT"))
		{
			this->m = 1;
			this->rize();
			cou = "FRONT";
		}
		if (ImGui::Selectable("NOCE"))
		{
			this->m = 9999;
			this->rize();
			cou = "NOCE";
			//timkk.Restart();
		}
		if (ImGui::Selectable("SOLID"))
		{
			this->k = false;
			this->rize();
			//cou = "FRONT";
		}
		if (ImGui::Selectable("WIR"))
		{
			this->k = true;
			this->rize();
			//cou = "NOCE";
		}
		ImGui::ListBoxFooter();
	}
	if (ImGui::ListBoxHeader("sampfile"))
	{
		if (ImGui::BeginCombo("FILTER",sbkwf.c_str()))
		{
			if (ImGui::Selectable("anisotropic"))
			{
				sampDesc.Filter = D3D11_FILTER_ANISOTROPIC;
				sbkwf = "anisotropic";
			}
			if (ImGui::Selectable("linear"))
			{
				sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
				sbkwf = "linear";
			}
			if (ImGui::Selectable("point"))
			{
				sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
				sbkwf = "point";
			}
			ImGui::EndCombo();
		}
		if (ImGui::Selectable("samoed"))
		{
			this->device->CreateSamplerState(&sampDesc, this->samplerState.ReleaseAndGetAddressOf());
		}
		ImGui::ListBoxFooter();
	}
	ImGui::End();
	//Assemble Together Draw Data
	ImGui::Render();
	//Render Draw Data
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
	//dynam->removeRigidBody(ballBody);
	this->swapchain->Present(0, NULL);
}

bool Graphics::InitializeDirectX(HWND hwnd)
{
	try
	{
		std::vector<AdapterData> adapters = AdapterReader::GetAdapters();

		if (adapters.size() < 1)
		{
			ErrorLogger::Log("No IDXGI Adapters found.");
			return false;
		}
		DXGI_SWAP_CHAIN_DESC scd;
		ZeroMemory(&scd, sizeof(DXGI_SWAP_CHAIN_DESC));

		scd.BufferDesc.Width = this->windowWidth;
		scd.BufferDesc.Height = this->windowHeight;
		scd.BufferDesc.RefreshRate.Numerator = 60;
		scd.BufferDesc.RefreshRate.Denominator = 1;
		scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		scd.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
		scd.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

		scd.SampleDesc.Count = 8;
		scd.SampleDesc.Quality = 0;

		scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		scd.BufferCount = 1;
		scd.OutputWindow = hwnd;
		scd.Windowed = TRUE;
		scd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
		scd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

		HRESULT hr;
		hr = D3D11CreateDeviceAndSwapChain(adapters[0].pAdapter, //IDXGI Adapter
			D3D_DRIVER_TYPE_UNKNOWN,
			NULL, //FOR SOFTWARE DRIVER TYPE
			NULL, //FLAGS FOR RUNTIME LAYERS
			NULL, //FEATURE LEVELS ARRAY
			0, //# OF FEATURE LEVELS IN ARRAY
			D3D11_SDK_VERSION,
			&scd, //Swapchain description
			this->swapchain.GetAddressOf(), //Swapchain Address
			this->device.GetAddressOf(), //Device Address
			NULL, //Supported feature level
			this->deviceContext.GetAddressOf()); //Device Context Address

		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		Microsoft::WRL::ComPtr<ID3D11Texture2D> backBuffer;
		hr = this->swapchain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(backBuffer.GetAddressOf()));
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		hr = this->device->CreateRenderTargetView(backBuffer.Get(), NULL, this->renderTargetView.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		//Describe our Depth/Stencil Buffer
		D3D11_TEXTURE2D_DESC depthStencilDesc;
		depthStencilDesc.Width = this->windowWidth;
		depthStencilDesc.Height = this->windowHeight;
		depthStencilDesc.MipLevels = 1;
		depthStencilDesc.ArraySize = 1;
		depthStencilDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		depthStencilDesc.SampleDesc.Count = 8;
		depthStencilDesc.SampleDesc.Quality = 0;
		depthStencilDesc.Usage = D3D11_USAGE_DEFAULT;
		depthStencilDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		depthStencilDesc.CPUAccessFlags = 0;
		depthStencilDesc.MiscFlags = 0;

		hr = this->device->CreateTexture2D(&depthStencilDesc, NULL, this->depthStencilBuffer.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		hr = this->device->CreateDepthStencilView(this->depthStencilBuffer.Get(), NULL, this->depthStencilView.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		this->deviceContext->OMSetRenderTargets(1, this->renderTargetView.GetAddressOf(), this->depthStencilView.Get());

		//Create depth stencil state
		D3D11_DEPTH_STENCIL_DESC depthstencildesc;
		ZeroMemory(&depthstencildesc, sizeof(D3D11_DEPTH_STENCIL_DESC));

		depthstencildesc.DepthEnable = true;
		depthstencildesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK::D3D11_DEPTH_WRITE_MASK_ALL;
		depthstencildesc.DepthFunc = D3D11_COMPARISON_FUNC::D3D11_COMPARISON_LESS_EQUAL;
		hr = this->device->CreateDepthStencilState(&depthstencildesc, this->depthStencilState.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");

		//Create the Viewport
		D3D11_VIEWPORT viewport;
		ZeroMemory(&viewport, sizeof(D3D11_VIEWPORT));

		viewport.TopLeftX = 0;
		viewport.TopLeftY = 0;
		viewport.Width = this->windowWidth;
		viewport.Height = this->windowHeight;
		viewport.MinDepth = 0.0f;
		viewport.MaxDepth = 1.0f;

		//Set the Viewport
		this->deviceContext->RSSetViewports(1, &viewport);

		//Create Rasterizer State
		D3D11_RASTERIZER_DESC rasterizerDesc;
		ZeroMemory(&rasterizerDesc, sizeof(D3D11_RASTERIZER_DESC));

		rasterizerDesc.FillMode = D3D11_FILL_MODE::D3D11_FILL_SOLID;
		rasterizerDesc.CullMode = D3D11_CULL_MODE::D3D11_CULL_BACK;
		hr = this->device->CreateRasterizerState(&rasterizerDesc, this->rasterizerState.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");
		D3D11_BLEND_DESC blendDesc;
		ZeroMemory(&blendDesc, sizeof(blendDesc));

		D3D11_RENDER_TARGET_BLEND_DESC rtbd;
		ZeroMemory(&rtbd, sizeof(rtbd));

		rtbd.BlendEnable = true;
		rtbd.SrcBlend = D3D11_BLEND::D3D11_BLEND_SRC_ALPHA;
		rtbd.DestBlend = D3D11_BLEND::D3D11_BLEND_INV_SRC_ALPHA;
		rtbd.BlendOp = D3D11_BLEND_OP::D3D11_BLEND_OP_ADD;
		rtbd.SrcBlendAlpha = D3D11_BLEND::D3D11_BLEND_ONE;
		rtbd.DestBlendAlpha = D3D11_BLEND::D3D11_BLEND_ZERO;
		rtbd.BlendOpAlpha = D3D11_BLEND_OP::D3D11_BLEND_OP_ADD;
		rtbd.RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE::D3D11_COLOR_WRITE_ENABLE_ALL;
		blendDesc.RenderTarget[0] = rtbd;

		hr = this->device->CreateBlendState(&blendDesc, this->blendState.GetAddressOf());
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");
		spriteBatch = std::make_unique<DirectX::SpriteBatch>(this->deviceContext.Get());
		spriteFont = std::make_unique<DirectX::SpriteFont>(this->device.Get(), L"Data\\Fonts\\comic_sans_ms_16.spritefont");

		//Create sampler description for sampler state
		ZeroMemory(&sampDesc, sizeof(sampDesc));
		sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
		sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
		sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
		sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
		sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
		sampDesc.MinLOD = -3.4f;
		sampDesc.MaxLOD = 3.4f;
		hr = this->device->CreateSamplerState(&sampDesc, this->samplerState.GetAddressOf()); //Create sampler state
		COM_ERROR_IF_FAILED(hr, "Failed to create sampler state.");
	}
	catch (COMException & exception)
	{
		ErrorLogger::Log(exception);
		return false;
	}
	//btVector3 worldAabbMin(-10000, -10000, -10000);
	//btVector3 worldAabbMax(10000, 10000, 10000);
	
	//delete dynam;
	//delete solver;
	//delete disp;
	//delete collisonc;
	//delete broad;
	return true;
}

bool Graphics::InitializeShaders()
{

	std::wstring shaderfolder = L"";
#pragma region DetermineShaderPath
	if (IsDebuggerPresent() == TRUE)
	{
#ifdef _DEBUG //Debug Mode
	#ifdef _WIN64 //x64
			shaderfolder = L"..\\x64\\Debug\\";
	#else  //x86 (Win32)
			shaderfolder = L"..\\Debug\\";
	#endif
	#else //Release Mode
	#ifdef _WIN64 //x64
			shaderfolder = L"..\\x64\\Release\\";
	#else  //x86 (Win32)
			shaderfolder = L"..\\Release\\";
	#endif
#endif
	}

	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{"POSITION", 0, DXGI_FORMAT::DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_CLASSIFICATION::D3D11_INPUT_PER_VERTEX_DATA, 0  },
		{"TEXCOORD", 0, DXGI_FORMAT::DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_CLASSIFICATION::D3D11_INPUT_PER_VERTEX_DATA, 0  },
		{"BONES", 0, DXGI_FORMAT::DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_CLASSIFICATION::D3D11_INPUT_PER_VERTEX_DATA, 0  },
	};

	UINT numElements = ARRAYSIZE(layout);

	if (!vertexshader.Initialize(this->device, shaderfolder + L"vertexshader.cso", layout, numElements))
		return false;

	if (!pixelshader.Initialize(this->device, shaderfolder + L"pixelshader.cso"))
		return false;


	return true;
}

bool Graphics::InitializeScene()
{
	//Textured Square
	try
	{
		//HRESULT hr = DirectX::CreateWICTextureFromFile(this->device.Get(), L"Data\\Textures\\seamless_grass.jpg", nullptr, grassTexture.GetAddressOf());
		//COM_ERROR_IF_FAILED(hr, "Failed to initialize constant buffer.");
		//hr = DirectX::CreateWICTextureFromFile(this->device.Get(), L"Data\\Textures\\pinksquare.jpg", nullptr, pinkTexture.GetAddressOf());
		//COM_ERROR_IF_FAILED(hr, "Failed to initialize constant buffer.");
		//hr = DirectX::CreateWICTextureFromFile(this->device.Get(), L"Data\\Textures\\seamless_pavement.jpg", nullptr, pavementTexture.GetAddressOf());
		//COM_ERROR_IF_FAILED(hr, "Failed to initialize constant buffer.");
		//Initialize Constant Buffer(s)
		HRESULT hr = this->cb_vs_vertexshader.Initialize(this->device.Get(), this->deviceContext.Get());
		COM_ERROR_IF_FAILED(hr, "Failed to initialize constant buffer.");
		hr = this->cb_ps_pixelshader.Initialize(this->device.Get(), this->deviceContext.Get());
		COM_ERROR_IF_FAILED(hr, "Failed to initialize constant buffer.");
		if (!model.Initialize("Data\\Objects\\Samples\\dodge_challenger.fbx", this->device.Get(), this->deviceContext.Get(),this->cb_vs_vertexshader,this->cb_ps_pixelshader,TTGGMF))//"Data\\Objects\\Samples\dodge_challenger.fbx",Data\\Objects\\dancing_vampire.dae
			return false;
		camera.SetProjectionValues(90.0f, static_cast<float>(windowWidth) / static_cast<float>(windowHeight), 0.1f, 200.0f);
		dynam = new btDiscreteDynamicsWorld(dispatcher,broadphase,solver,collisionConfig);
		btTransform transsss;
		transsss.setIdentity();
		transsss.setOrigin(btVector3(0, 0, 0));
		btStaticPlaneShape* plane = new btStaticPlaneShape(btVector3(0, 1, 0),0);
		btMotionState* motion = new btDefaultMotionState(transsss);
		btRigidBody::btRigidBodyConstructionInfo info(0, motion,plane);
		btRigidBody* body = new btRigidBody(info);
		dynam->setGravity(btVector3(0, gra, 0));
		//transsss.setIdentity();
		//transsss.setOrigin(btVector3(0, 0, 0));
		//btBoxShape* sphere = new btBoxShape(btVector3(20, 4, 20));
		//btMotionState* motion = new btDefaultMotionState(transsss);
		//btRigidBody::btRigidBodyConstructionInfo info(0, motion, sphere, inertia);
		//btRigidBody* body = new btRigidBody(info);
		dynam->addRigidBody(body);
		//ball.push_back(body);
		//delete plane;
		//model.tru = true;
		for (int i = 0; i < TTGMMMM; i++)
		{
			a[i] = new Model;
			tt[i] = new XMFLOAT3;
			tt[i]->x = 0.0f;
			tt[i]->y = 0.0f;
			tt[i]->z = 0.0f;
		}
		for (int j = 0; j < TTEEEP; j++)
		{
			mlop[j] = new XMFLOAT3;
			mlop[j]->x = 0.0f;
			mlop[j]->y = 0.0f;
			mlop[j]->z = 0.0f;
		}
		//model.t = true;
		//model.IncTTg("Data\\Objects\\3.fbx");
	}
	catch (COMException & exception)
	{
		ErrorLogger::Log(exception);
		return false;
	}
	return true;
}


void Graphics::rizemove(bool TR,int W,bool T,int TTF)
{
	if (!T)
	{
		if (!TR)
		{
			this->a[W]->SetPosition(tt[W]->x, tt[W]->y, tt[W]->z);
		}
		else
		{
			this->a[W]->AdjustPosition(tt[W]->x, tt[W]->y, tt[W]->z);
		}
	}
	else
	{
		//ball[W]->setAngularVelocity(btVector3(tt[W]->x, tt[W]->y, tt[W]->z));
		dynam->stepSimulation(1 / 60.0);
		ball[W]->getMotionState()->getWorldTransform(ans[W]);
		//ball[W + 1]->getMotionState()->getWorldTransform(ans[W + 1]);
		this->a[W]->pos2[TTF]->x = ans[W].getOrigin().getX();
		this->a[W]->pos2[TTF]->y = ans[W].getOrigin().getY();
		this->a[W]->pos2[TTF]->z = ans[W].getOrigin().getZ();
		this->a[W]->ros2[0]->x = ans[W].getRotation().getX();
		this->a[W]->ros2[0]->y = ans[W].getRotation().getY();
		this->a[W]->ros2[0]->z = ans[W].getRotation().getZ();
		//tt[W]->x = ans[W].getOrigin().getX();
		//tt[W]->y = ans[W].getOrigin().getY();
		//tt[W]->z = ans[W].getOrigin().getZ();
		//this->a[W]->SetPosition(tt[W]->x, tt[W]->y, tt[W]->z);
		//this->a[W]->SetPosition(ans[W].getOrigin().getX(), ans[W].getOrigin().getY(), ans[W].getOrigin().getZ());
	}
}

void Graphics::r(int n)
{
	ball[n]->setActivationState(DISABLE_DEACTIVATION);
	ball[n]->setLinearVelocity(btVector3(mlop[n]->x, mlop[n]->y, mlop[n]->z));
}

void Graphics::cratshamp(float sha, float x, float y, float z, btScalar mass)
{
	transsss.setIdentity();
	transsss.setOrigin(btVector3(x, y, z));
	btSphereShape* sphere = new btSphereShape(sha);
	if (mass != 0.0)
	{
		sphere->calculateLocalInertia(mass,inertia);
	}
	btMotionState* motion = new btDefaultMotionState(transsss);
	btRigidBody::btRigidBodyConstructionInfo info(mass, motion, sphere,inertia);
	btRigidBody* body =new btRigidBody(info);
	//body->setFriction(100000);
	//body->setRestitution(-100000);
	//body->applyImpulse(btVector3(-22,-22,-22),btVector3(-22,-22,-22));
	//body->applyCentralImpulse(btVector3(-22, -22, -22));
	dynam->addRigidBody(body);
	ball.push_back(body);
}

void Graphics::cratshamp2(float sha, float x, float y, float z, btScalar mass, float u)
{
	transsss.setIdentity();
	transsss.setOrigin(btVector3(x, y, z));
	//trans->setRotation(btQuaternion(0,90,0));
	btCylinderShape* sphere = new btCylinderShape(btVector3(sha / 2.0, u / 2.0, sha / 2.0));
	if (mass != 0.0)
	{
		sphere->calculateLocalInertia(mass, inertia);
	}
	btMotionState* motion = new btDefaultMotionState(transsss);
	btRigidBody::btRigidBodyConstructionInfo info(mass, motion, sphere, inertia);
	btRigidBody* body = new btRigidBody(info);
	dynam->addRigidBody(body);
	ball.push_back(body);
}

void Graphics::cratshamp3(float sha, float x, float y, float z, btScalar mass, float u)
{
	transsss.setIdentity();
	transsss.setOrigin(btVector3(x, y, z));
	//trans->setRotation(btQuaternion(0,90,0));
	btConeShape* sphere = new btConeShape(sha, u);
	if (mass != 0.0)
	{
		sphere->calculateLocalInertia(mass, inertia);
	}
	btMotionState* motion = new btDefaultMotionState(transsss);
	btRigidBody::btRigidBodyConstructionInfo info(mass, motion, sphere, inertia);
	btRigidBody* body = new btRigidBody(info);
	dynam->addRigidBody(body);
	ball.push_back(body);
}

void Graphics::cratshamp4(float shax, float x, float y, float z, btScalar mass, float shay,float shaz)
{
	transsss.setIdentity();
	transsss.setOrigin(btVector3(x, y, z));
	btBoxShape* sphere = new btBoxShape(btVector3(shax, shay,shaz));
	if (mass != 0.0)
	{
		sphere->calculateLocalInertia(mass, inertia);
	}
	btMotionState* motion = new btDefaultMotionState(transsss);
	btRigidBody::btRigidBodyConstructionInfo info(mass, motion, sphere, inertia);
	btRigidBody* body = new btRigidBody(info);
	dynam->addRigidBody(body);
	ball.push_back(body);
}

void Graphics::cratshamp5(float sha, float x, float y, float z, btScalar mass, float u)
{
	transsss.setIdentity();
	transsss.setOrigin(btVector3(x, y, z));
	btCapsuleShape* sphere = new btCapsuleShape(sha,u);
	if (mass != 0.0)
	{
		sphere->calculateLocalInertia(mass, inertia);
	}
	btMotionState* motion = new btDefaultMotionState(transsss);
	btRigidBody::btRigidBodyConstructionInfo info(mass, motion, sphere, inertia);
	btRigidBody* body = new btRigidBody(info);
	dynam->addRigidBody(body);
	ball.push_back(body);
}

void Graphics::rize()
{
	D3D11_RASTERIZER_DESC rasterizerDesc;
	ZeroMemory(&rasterizerDesc, sizeof(D3D11_RASTERIZER_DESC));
	if (!k)
	{
		rasterizerDesc.FillMode = D3D11_FILL_MODE::D3D11_FILL_SOLID;
	}
	else
	{
		rasterizerDesc.FillMode = D3D11_FILL_MODE::D3D11_FILL_WIREFRAME;
	}
	switch (this->m)
	{
	case 0:
		rasterizerDesc.CullMode = D3D11_CULL_MODE::D3D11_CULL_BACK;
		break;
	case 1:
		rasterizerDesc.CullMode = D3D11_CULL_MODE::D3D11_CULL_FRONT;
		break;
	default:
		rasterizerDesc.CullMode = D3D11_CULL_MODE::D3D11_CULL_NONE;
	}
	this->device->CreateRasterizerState(&rasterizerDesc, this->rasterizerState.ReleaseAndGetAddressOf());
}

void Graphics::rizemodel()
{
	a[TTGGGG]->l = true;
	a[TTGGGG]->g = false;
	a[TTGGGG]->Initialize(op, this->device.Get(), this->deviceContext.Get(), this->cb_vs_vertexshader, this->cb_ps_pixelshader,TTGGMF);
	//a[TTGGGG]->t = true;
	//a[TTGGGG]->IncTTg("Data\\Objects\\2.fbx");
	//a[TTGGGG]->t = true;
	//a[TTGGGG]->mp += 1;
	//a[TTGGGG]->IncTTg("Data\\Objects\\1.fbx");
	TTGGGG += 1;
}
