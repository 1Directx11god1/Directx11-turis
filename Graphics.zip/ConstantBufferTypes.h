#pragma once
#include <DirectXMath.h>

struct CB_VS_vertexshader
{
	DirectX::XMMATRIX mat;
	DirectX::XMMATRIX mac;
	DirectX::XMMATRIX map[4];
};

struct CB_PS_pixelshader
{
	float alpha = 1.0f;
};

